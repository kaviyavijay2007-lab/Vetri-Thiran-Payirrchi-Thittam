"""ComicCraft application package."""
