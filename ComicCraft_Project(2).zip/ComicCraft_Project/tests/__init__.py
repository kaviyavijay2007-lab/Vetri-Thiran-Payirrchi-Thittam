"""ComicCraft test package."""
